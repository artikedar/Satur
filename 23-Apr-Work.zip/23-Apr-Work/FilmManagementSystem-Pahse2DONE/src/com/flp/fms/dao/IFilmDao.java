package com.flp.fms.dao;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language> getLanguages();

	public List<Category> getCategories();
	
	public void addFilm(Film film);
	
	public List<Film> getAllFilms();
	
	public int removeFilm(Film film);

	public List<Film> searchFilm(Film film);
	
	public List<Film> searchFilm2(String title);

	public Film updateFilm(int id);
	
	public int updatedFilm(int id, Film film);

	public int searchForRemove(Film film);

	public int removeFilmById(int opt1);

	public int removeFilmByTitle(String opt3);

	public int removeFilmByRating(int rating);
	

	
	
}
