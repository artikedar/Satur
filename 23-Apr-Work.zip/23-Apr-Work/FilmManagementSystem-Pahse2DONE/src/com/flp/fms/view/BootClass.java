package com.flp.fms.view;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.service.ActorServiceImpl;
import com.flp.service.FilmServiceImpl;
import com.flp.service.IActorService;
import com.flp.service.IFilmService;

public class BootClass {
public static void main(String[] args){
		
		
		UserInteraction userInter=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
		IActorService actorService=new ActorServiceImpl(); 
		
		int opt;
		int opt1;
		int opt2;
		
		String choice;
		
		
		do{
			menuSelection();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Your Option: ");
			opt=sc.nextInt();
		switch (opt) {
		case 1:
			Film film=userInter.addFilm(filmService.getLanguages(),filmService.getCategories(),actorService.getActors());
			filmService.addFilm(film);
			System.out.println(film);
			break;
		
		case 3:
			
			System.out.println("1. Remove Film By Id");
			System.out.println("2. Remove Film By Title");
			System.out.println("3. Remove Film By Rating");
			System.out.println("Enter Your Option: ");
			int option=sc.nextInt();
			
			switch(option) {
			case 1:	
				System.out.println("Please Enter the Film Id:");
				opt1=sc.nextInt();
				int count=filmService.removeFilmById(opt1);
				break;
				
			case 2:
				System.out.println("Please Enter the Title:");
				String opt3=sc.next();
				int count1=filmService.removeFilmByTitle(opt3);
				break;
				
			case 3:
				System.out.println("Please Enter rating betweeen 1-5");
				int rating=sc.nextInt();
				int count2=filmService.removeFilmByRating(rating);
				
				break;
				}
			
			break;
	
			
			
			
		case 4:
					
			Film serFilm=userInter.searchFilm(filmService.getLanguages(),filmService.getCategories(),actorService.getActors());
			List<Film> resFilm=filmService.searchFilm(serFilm);
			System.out.println("Boot got Result:"+resFilm);
			userInter.printFilm(resFilm);
			break;
			
		case 5:
			
			userInter.getAllFilm();
			break;
			
		case 2:
			int filmId2=userInter.readFilmByID();
			Film film1=filmService.updateFilm(filmId2);
			System.out.println("Boot got this:"+film1);
			
			if(film1==null){
				System.out.println("Film Does Not Exists");
			}
			else {
				System.out.println(film1);
				Film filmNew=userInter.addFilm(filmService.getLanguages(),filmService.getCategories(),actorService.getActors());
				filmNew.setFilm_ID(filmId2);
				filmService.updatedFilm(filmId2, filmNew);
			}
			
			}
		
		System.out.println("Wish to Continue?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		
	}
	
	
	
	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
	
	
	
	
		
		
		
		
		
	
	
}
