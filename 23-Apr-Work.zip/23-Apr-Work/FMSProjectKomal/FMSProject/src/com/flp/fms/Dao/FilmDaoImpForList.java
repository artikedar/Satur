package com.flp.fms.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import com.flp.fms.domain.Film;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;

public class FilmDaoImpForList implements IFilmDao{

	private Map<Integer, Film> film_Repository=new HashMap<>();
	@Override
	public List<Language> getOriginalLanguage() {
		List<Language>languages=new ArrayList<>();
		
		languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));
		
		/*Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				
				
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		
		return languages;
	}

	@Override
	public List<Category> getCategory() {
		List<Category> category=new ArrayList<>();
		category.add(new Category(1, "Comic"));
		category.add(new Category(2, "Horrer"));
		category.add(new Category(3, "Action"));
		
		return category;
	}
	
	//CURD Operation
		@Override
		public void addFilm(Film film) {
			film_Repository.put(film.getFilm_Id(), film);
			
		}


		@Override
		public Map<Integer, Film> getAllFilms() {
			
			return film_Repository;
		}

		@Override
		public Map<Integer, Film> searchFilm() {
			return film_Repository;
			
		}

		@Override
		public Map<Integer, Film> removeFilm() {
			
			return  film_Repository;
		}

		/*public Connection getConnection(){
			
			Connection connection=null;
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/FilmManagementSystem","root","Pass1234");
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return connection;
		}
		
*/    
		
		//
		public Film searchFilm(int filmId1) {
			
			Map<Integer, Film> filmList=getAllFilms();
			Collection<Film>filmList1=filmList.values();
			Film filmCurrent=new Film();
			boolean flag=false;
			for(Film film:filmList1)
			{
				if(filmId1==film.getFilm_Id())
				{
					System.out.println("Film is exists");
					System.out.println(film);
					filmCurrent=film;
					flag=true;
					break;
				}
			}
			
			return filmCurrent ;
		}

		public void updateFilm(Film film1) {
			 
			addFilm(film1);
			
		}
	

}
