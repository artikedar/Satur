package com.flp.fms.view;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.service.ActorServiceImpl;
import com.flp.service.FilmServiceImp;
import com.flp.service.IFilmService;

public class BootClass {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmservice=new FilmServiceImp();
		ActorServiceImpl actorServe=new ActorServiceImpl();
		do{
		menuSelection();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1:
				Film film=userInteraction.addFilm(filmservice.getLanguage(),filmservice.getCategory(),actorServe.getActorList());
//				System.out.println(film);
				filmservice.addFilm(film);
				break;
			case 2:
				int filmId1=userInteraction.readFilmId();
				film=filmservice.searchFilms(filmId1);
				System.out.println("update");
				/*System.out.println(film);*/
				if(film==null)
					System.out.println("Film Not Present");

				else{
					System.out.println(film);
					Film film1=userInteraction.addFilm(filmservice.getLanguage(),filmservice.getCategory(),actorServe.getActorList());
					film1.setFilm_Id(filmId1);
					filmservice.updateFilm(film1);
				}
				
				
				break;
			case 3:/*Map<Integer, Film>filmList2=filmservice.removeFilm();
		    Collection<Film>film_list2=filmList2.values();
		    userInteraction.removeFilm(film_list2);*/

				String choice;
				do{
				deleteMenuSelection();
				System.out.println("Enter your choice: ");
				int opt1=sc.nextInt();
				
				switch(opt1){
				case 1:
					System.out.println("Please enter film Id to delete: ");
				    int filmId=sc.nextInt();
					userInteraction.deleteFilmById(filmservice.getAllFilms(),filmId);
					break;
					
				case 2:
					System.out.println("Please enter film Title to delete: ");
				    String filmTitle=sc.next();
				    userInteraction.deleteFilmByTitle(filmservice.getAllFilms(),filmTitle);
					
					break;
				case 3:
					System.out.println("Please enter film Rating to delete: ");
				    int rating=sc.nextInt();
				    userInteraction.deleteFilmByRatings(filmservice.getAllFilms(),rating);
					break;
					
				case 4:
					break;
				}
				System.out.println("Wish to do more deletion?[y|n]");
				choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			
				break;
			case 4:
				Map<Integer, Film>filmList1=filmservice.searchFilms();
			    Collection<Film>film_list1=filmList1.values();
			    userInteraction.searchFilm(film_list1);
				break;
			case 5:
				Map<Integer, Film>filmList=filmservice.getAllFilms();
			    Collection<Film>film_list=filmList.values();
			    userInteraction.getAllFilm(film_list);
				break;
			case 6:
				System.exit(0);
		}
		}while(option<6);
	}

	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}
public static void deleteMenuSelection(){
		
		System.out.println("1.Delete by ID");
		System.out.println("2.Delete by Title");
		System.out.println("3.Delete Ratings");
		System.out.println("4.Exit");
		
	}
}
