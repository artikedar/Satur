package com.flp.fms.Dao;

import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {
	
	public List<Language>getOriginalLanguage();
	public List<Category>getCategory();
	public void addFilm(Film film);
	public Map<Integer, Film> getAllFilms();
	public Map<Integer, Film> searchFilm();
	public Map<Integer, Film> removeFilm();

}
